import { ScrollSmoothDirective } from './scroll-smooth.directive';

describe('ScrollSmoothDirective', () => {
  it('should create an instance', () => {
    const directive = new ScrollSmoothDirective();
    expect(directive).toBeTruthy();
  });
});
